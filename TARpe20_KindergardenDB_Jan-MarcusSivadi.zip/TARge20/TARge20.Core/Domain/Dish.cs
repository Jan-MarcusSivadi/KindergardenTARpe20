﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Dish
    {
        [Key]
        public Guid Id { get; set; }
        public List<Group> GroupId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public List<Serving> ServingId { get; set; }
        public string Description { get; set; }
    }
}