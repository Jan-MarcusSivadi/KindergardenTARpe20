﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Queue
    {
        [Key]
        public Guid Id { get; set; }
        public List<Children> ChildrenId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}