﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Menu
    {
        [Key]
        public Guid Id { get; set; }
        public List<Dish> DishId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}