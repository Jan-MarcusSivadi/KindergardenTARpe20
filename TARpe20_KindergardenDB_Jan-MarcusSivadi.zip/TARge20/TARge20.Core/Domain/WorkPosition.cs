﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class WorkPosition
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public int AmountAvailable { get; set; }
        public List<Employee> EmployeeId { get; set; }
        public string Description { get; set; }
    }
}