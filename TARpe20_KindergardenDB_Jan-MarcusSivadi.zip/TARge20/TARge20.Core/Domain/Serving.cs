﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Serving
    {
        [Key]
        public Guid Id { get; set; }
        public string Portion { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
    }
}