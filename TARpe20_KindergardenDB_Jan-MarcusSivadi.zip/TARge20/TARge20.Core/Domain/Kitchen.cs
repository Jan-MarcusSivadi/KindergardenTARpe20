﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Kitchen
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Menu> MenuId { get; set; }
        public string Description { get; set; }
    }
}