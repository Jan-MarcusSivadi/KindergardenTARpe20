﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Children
    {
        [Key]
        public Guid Id { get; set; }
        public List<Group> GroupId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public DateTime JoinedAt { get; set; }
        public DateTime LeftAt { get; set; }
        public List<Absence> AbsenceId { get; set; }
        public List<Relocation> RelocationId { get; set; }
    }
}