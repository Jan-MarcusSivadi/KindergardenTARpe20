﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Absence
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public DateTime Reason { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
    }
}