﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Kindergarden
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public List<Group> GroupId { get; set; } // FK
        public List<Registerings> RegisteringId { get; set; } // FK
    }
}
