﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Registerings
    {
        [Key]
        public Guid Id { get; set; }
        public List<Queue> QueueId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Aadress { get; set; }
        public DateTime RegisteredAt { get; set; }
        
    }
}
