﻿using Microsoft.EntityFrameworkCore;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }

        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.
        public DbSet<Kindergarden> Kindergardens { get; set; }
        public DbSet<Registerings> Registers { get; set; }
        public DbSet<Queue> Queues { get; set; }
        public DbSet<Children> Childrens { get; set; }
        public DbSet<Relocation> Relocations { get; set; }
        public DbSet<Absence> Absences { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<WorkPosition> WorkPositions { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Kitchen> Kitchens { get; set; }
        public DbSet<Menu> Menus { get; set; }
        public DbSet<Dish> Dishes { get; set; }
        public DbSet<Serving> Servings { get; set; }
    }
}